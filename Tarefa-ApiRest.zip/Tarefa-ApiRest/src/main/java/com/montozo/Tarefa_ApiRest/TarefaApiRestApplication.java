package com.montozo.Tarefa_ApiRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarefaApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TarefaApiRestApplication.class, args);
	}

}
