package com.montozo.Tarefa_ApiRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TarefaApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
